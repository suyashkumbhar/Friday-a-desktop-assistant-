import numpy as np 
import pandas as pd 


import sklearn


import streamlit as st 

import pickle
st.title("Sentiment Analyis")
title = st.text_input('Input text', '')
st.write('The current movie title is', title)

import pickle

# save
with open('model.pkl','wb') as f:
    pickle.dump(SVCmodel,f)

# load
 with open('model.pkl', 'rb') as f:
    SVCmodel = pickle.load(f)

# x = SVCmodel.predict([['folks said daikon paste could treat cytokine storm pfizerbiontech']])
s = [title]
X = vect.transform(s)
# print(X)
R = SVCmodel.predict(X)
st.write(R)