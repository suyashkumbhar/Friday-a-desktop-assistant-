import pyttsx3
import datetime
import speech_recognition as sr
import wikipedia
import webbrowser
import os
from smtplib import *
import smtplib
import wolframalpha
import sys



from PyQt5 import QtWidgets,QtGui,QtCore
from PyQt5.QtCore import QTimer,QTime,QDate,Qt 
from PyQt5.QtGui import QMovie
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from PyQt5.uic import loadUiType

from deskbot import Ui_MainWindow


try:
    app=wolframalpha.Client("79KE46-JT933J6QK9")
except:
    print("some featrues might not working")


engine=pyttsx3.init('sapi5')
voices=engine.getProperty('voices')

engine.setProperty('voice',voices[1].id)
print(voices[1].id)


def wishMe():
        hour=int(datetime.datetime.now().hour)

        if hour>=0 and hour<12:
            speak("Good Morning !")
        elif hour>=12 and hour<18:
            speak("Good Afternoon !")
        else:
            speak("Good Evening !")

def speak(audio):
        engine.say(audio)
        engine.runAndWait()


class MainThread(QThread):
    def __init__(self):
        super(MainThread,self).__init__()

    def run(self):
        self.taskExecution()  

    def takeCommand(self):
        #speak("I am friday sir. please tell me how may I help you")
        #wishMe()
        
        r=sr.Recognizer()
        with sr.Microphone() as source:
            print("listening")
            speak("Listening")
            r.pause_threshold = 1
            audio = r.listen(source)

        try:
            print("Recognizing")
            speak("Recognizing")
            self.query = r.recognize_google(audio,language='en-in')
            print("user said:",(self.query))

        except Exception as e:
            #print(e)
            print("say that again please")
            speak("Say that again please")
            return "None"
        return self.query




    def taskExecution(self):
        #speak("i am friday sir tell me how may i help you")    
        #wishMe()

        while True:
        
        #if 1:
            self.query=self.takeCommand().lower()

            #logic for executing tasks depended on self.query
            
            if 'wikipedia' in self.query:
                speak("Searching wikipedia.....")
                self.query=self.query.replace("wikipedia","")
                results=wikipedia.summary(self.query,sentences=2)
                speak("According to Wikipedia")
                print(results)
                speak(results)

            elif 'open geeks for geeks' in self.query:
                webbrowser.open("geeksforgeeks.com")

            elif 'open youtube' in self.query:
                webbrowser.open("youtube.com")

            elif 'open google' in self.query:
                webbrowser.open("google.com")

            elif 'open linkedin' in self.query:
                webbrowser.open("linkedin.com")

            elif 'open coursera' in self.query:
                webbrowser.open("coursera.com")

            elif 'open github' in self.query:
                webbrowser.open("github.com")

            elif 'open classroom' in self.query:
                webbrowser.open("classroom.google.com")







            elif 'play music' in self.query:
                music_dir='C:\\Users\\suyas\\Music\\Playlists'
                songs=os.listdir(music_dir)
                print(songs)
                os.startfile(os.path.join(music_dir,songs[0]))
            elif 'time ' in self.query:
                strTime=datetime.datetime.now().strftime("%H:%M:%S")
                speak(f"Sir, the time is {strTime}")

            elif 'open vs code' in self.query:
                codePath="C:\\Users\\suyas\\AppData\\Local\\Programs\\Microsoft VS Code\\Code.exe"
                os.startfile(codePath)

            elif 'open notepad' in self.query:
                codePath="C:\\Program Files\\WindowsApps\\Microsoft.WindowsNotepad_10.2102.13.0_x64__8wekyb3d8bbwe\\Notepad"
                os.startfile(codePath)

            elif 'open word' in self.query:
                codePath="C:\\Program Files\\Microsoft Office\\root\\Office16\\WINWORD.EXE"
                os.startfile(codePath)

            elif 'open powerpoint' in self.query:
                codePath="C:\\Program Files\\Microsoft Office\\root\\Office16\\POWERPNT.EXE"
                os.startfile(codePath)

            elif 'open excell' in self.query:
                codePath="C:\\Program Files\\Microsoft Office\\root\\Office16\\EXCEL.EXE"
                os.startfile(codePath)

            elif 'open edge' in self.query:
                codePath="C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe"
                os.startfile(codePath)

            

            elif 'pc perfomance' in self.query:
                codePath="C:\ProgramData\Microsoft\Windows\Start Menu\Programs\System Tools\Task Manager.lnk"
                os.startfile(codePath)



                


            elif 'send email' in self.query:
            

                maildir={'satej':'satej9949@gmail.com','shivam':'shivamdesai7205@gmail.com'}

                speak("to whom i should send mail sir ?")
                
                self.query=self.takeCommand().lower()

                namekey=self.query
                if namekey in maildir.keys():
                    global recip
                    recip= maildir[namekey]

                to=recip    
                
                speak("What should I say?")

                self.query=self.takeCommand()
                message=self.query

                def sendEmail(to,message):
                    obj=smtplib.SMTP_SSL("smtp.gmail.com",465)
                    obj.login("suyashkumbhar.9357@gmail.com","yejocdinlteyyxxe")
                    obj.sendmail("suyashkumbhar.9357@gmail.com",to,message)
                    obj.quit()

                try:
                    speak("Sending email")  
                    sendEmail(to,message)
                    speak("Email has been sent successfully!")
                except Exception as e:
                    #print(e)
                    speak("Sorry sir !  not able to send this email try again") 


            #whether forecasting

            elif ' weather' in self.query:

                speak("which locations whether do you want know?")
                self.query=self.takeCommand()
                
                try:
                    result=app.self.query(self.query)
                    print(next(result.results).text)
                    speak(next(result.results).text)

                except:
                    print("connection error")


            elif 'joke' in self.query:

                
                self.query="tell me a joke"
                
                try:
                    result=app.self.query(self.query)
                    print(next(result.results).text)
                    speak(next(result.results).text)

                except:
                    speak("connection error")


            elif 'story' in self.query:

                
                self.query="tell me a story"
                
                try:
                    result=app.self.query(self.query)
                    print(next(result.results).text)
                    speak(next(result.results).text)

                except:
                    speak("connection error")


            elif 'temperature' in self.query:

                
                self.query="what is temperature outside"
                
                try:
                    result=app.self.query(self.query)
                    print(next(result.results).text)
                    speak(next(result.results).text)

                except:
                    speak("connection error")


            elif 'movies' in self.query:

                
                #speak("what informmation related to movies do you want")

                #self.query=takeCommand()
                
                try:
                    result=app.self.query(self.query)
                    print(next(result.results).text)
                    speak(next(result.results).text)

                except:
                    speak("connection error")


            elif 'date and time' in self.query:
                
                try:
                    result=app.self.query(self.query)
                    print(next(result.results).text)
                    speak(next(result.results).text)

                except:
                    speak("connection error")


            elif 'tell me about' in self.query:
                
                try:
                    result=app.self.query(self.query)
                    print(next(result.results).text)
                    speak(next(result.results).text)

                except:
                    speak("connection error")


        
            '''else:
                temp=self.query.replace(" ","+")
                url="https://www.google.com/search?q"
                res="sorry sir I cant understand but i searched from internet to give your answer !"
                print(res)
                speak(res)
                webbrowser.open(url+temp)'''

                




startExecution=MainThread() #thread object 





        

class Main(QMainWindow):
    def __init__(self):
        super().__init__()
        self.ui=Ui_MainWindow()
        self.ui.setupUi(self)
        self.ui.pushButton.clicked.connect(self.startTask)
        self.ui.pushButton_2.clicked.connect(self.close)

    def startTask(self):
        self.ui.movie=QtGui.QMovie("E:/Python project/GUIimg/79ab9f804b5ebbdd514af3329cad6e0c.gif")#:/newPrefix/79ab9f804b5ebbdd514af3329cad6e0c.gif
        self.ui.label_2.setMovie(self.ui.movie)
        self.ui.movie.start()

        startExecution.start()
        



app=QApplication(sys.argv)
friday=Main()
friday.show()
exit(app.exec_())